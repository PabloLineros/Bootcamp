import { Component } from '@angular/core';

@Component({
  selector: 'app-body',
  standalone: true,
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent { }
